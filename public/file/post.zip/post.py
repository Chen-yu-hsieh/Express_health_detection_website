import requests

URL = "https://health-detection.herokuapp.com/user"

############################################################
# Send one data to database                                #
#                                                          #
# Params                                                   #
#       user_id: String. Generated from profile.           #
#       sensor_id: String.                                 #
#       data : Number. Can be integer or float.            #
#       year : String. yyyy                                #
#       month: String. mm                                  #
#       day  : String. dd                                  #
#       time :  String. hh:mm:ss                           #
############################################################

# Account for test
# username: test5
# password: 123456
# If your user_id and sensor_id are default,
# data you post will be in sensor "Respiration_detect"
def post_data(data, year, month, day, time, user_id="6297543ea294fa48b06a8d89", sensor_id="629c854276d53007e4a66116"):
    my_data = {'user': user_id, 'sensor': sensor_id, 'data': data, 'year': year, 'month': month, 'day': day, 'time': time}
    response = requests.post(URL, data=my_data)
   
    if(response.status_code ==  200):
        return my_data
    else:
        return response.text